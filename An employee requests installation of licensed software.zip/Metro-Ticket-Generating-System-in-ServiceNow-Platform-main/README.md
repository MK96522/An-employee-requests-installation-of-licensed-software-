# Metro-Ticket-Generating-System-in-ServiceNow-Platform
Digitized metro ticket booking using ServiceNow for fast and automated ticket generation through QR codes. The system enables users to select stations and travel details, automatically calculates fares, and generates digital tickets instantly using Service Catalog, Flow Designer, and Notifications.
